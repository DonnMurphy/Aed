package com.jambons.aed;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class AccountView extends AppCompatActivity {

    EthUtils eth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_view);

        // Setting View Eleemnts
        TextView tvAccountName = findViewById(R.id.tvAccountName);
        TextView tvWalletNetwork = findViewById(R.id.tvWalletNetwork);
        TextView tvWalletAddress = findViewById(R.id.tvWalletAddress);
        TextView tvWalletBalence = findViewById(R.id.tvWalletBalence);

        //Setting Eth Utils
        eth = new EthUtils(this, this);
        eth.connectToEthNetwork();
        //eth.createWallet();
        eth.getAddress();

        // Setting Values For Wallet Info
        tvWalletAddress.setText(eth.getAddress1());
        tvAccountName.setText("DonieSheep"); //TODO - Replace This with FireBase Call???
        tvWalletNetwork.setText("RopSten"); //TODO - Maybe Change this to a function to check which network??
        tvWalletNetwork.setText("JOTARO"); //TODO - Maybe Change this to a function to check Bal??

    }
}
